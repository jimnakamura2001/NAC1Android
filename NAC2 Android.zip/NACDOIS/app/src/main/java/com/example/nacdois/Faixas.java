package com.example.nacdois;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ScrollView;
import android.widget.TextView;

import java.text.DecimalFormat;

public class Faixas extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_faixas);
        DecimalFormat A = new DecimalFormat("#.##");

        ScrollView scrollView = findViewById(R.id.scrollView);

        TextView FCM = findViewById(R.id.FCM);
        TextView caminhadaFastesquerda = findViewById(R.id.caminhadaFastesquerda);
        TextView troteesquerda = findViewById(R.id.troteesquerda);
        TextView corridaSuaveesquerda = findViewById(R.id.corridaSuaveesquerda);
        TextView corridaFicandoHardesquerda = findViewById(R.id.corridaFicandoHardesquerda);
        TextView corridaHardesquerda = findViewById(R.id.corridaHardesquerda);

        Intent intent = getIntent();
        Bundle b = intent.getExtras();
        String info = b.getString("INFORMACAO");

        FCM.setText("Esta página mostra suas Faixas de Frequencia Cardíaca que têm como base o seu FCM: " + info + "bpm e é mostrada de acordo com a intensidade do esporte.");

        double calcula = Double.parseDouble(info);

        //CAMINHADA RAPIDA =========================================================================================

        double contaUm = calcula * 0.55;
        double contaUm2 = calcula * 0.6;

        //String caminhadaFast = Double.toString(contaUm);
        //String caminhadaFast2 = Double.toString(contaDois);
        caminhadaFastesquerda.setText(A.format(contaUm) + " até " + A.format(contaUm2));

        //TROTE=====================================================================================================

        double contaDois = calcula * 0.65;
        double contaDois2 = calcula * 0.70;

        troteesquerda.setText(A.format(contaDois) + " até " + A.format(contaDois2));

        //CORRIDA LEVE==============================================================================================

        double contaTres = calcula * 0.75;
        double contaTres2 = calcula * 0.80;

        corridaSuaveesquerda.setText(A.format(contaTres) + " até " + A.format(contaTres2));

        //CORRIDA MODERADA ============================================================================================

        double contaQuatro = calcula * 0.85;
        double contaQuatro2 = calcula * 0.90;

        corridaFicandoHardesquerda.setText(A.format(contaQuatro) + " até " + A.format(contaQuatro2));

        //CORRIDA INTENSA==============================================================================================

        double contaCinco = calcula * 0.95;

        corridaHardesquerda.setText("Acima de " + A.format(contaCinco));

    }

}
