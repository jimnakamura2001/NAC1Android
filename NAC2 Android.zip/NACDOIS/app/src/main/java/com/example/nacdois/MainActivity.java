package com.example.nacdois;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ScrollView scrollView = findViewById(R.id.scrollView);

    }

    public void CalculaFCM(View v){

        EditText joao = findViewById(R.id.colocaIdade);
        TextView FCMDAPESSOA = findViewById(R.id.mostraIdade);


        String srtFCM = joao.getText().toString();
        int idade = Integer.parseInt(srtFCM);
        int FCM = (220 - idade);
        String resultado = Integer.toString(FCM);

        FCMDAPESSOA.setText(resultado);

    }

    public void gotoFaixas(View view){
        TextView FCMDAPESSOA = findViewById(R.id.mostraIdade);

        Intent intent = new Intent(this, Faixas.class);

        String info = FCMDAPESSOA.getText().toString();
        intent.putExtra("INFORMACAO", info);

        startActivity(intent);
    }
}
