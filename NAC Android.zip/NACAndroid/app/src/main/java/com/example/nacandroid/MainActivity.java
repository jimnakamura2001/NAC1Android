package com.example.nacandroid;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Intent intent = getIntent();

    }

    public int key = 0;
    Bundle bundle = new Bundle();

    public void Submarino(View view){

        key = 1;
        Intent intent = new Intent(this,Todas.class);
        intent.putExtra("TOKYO", key);
        startActivity(intent);

    }

    public void Ebay(View view){
        key = 2;

        Intent intent = new Intent(this,Todas.class);
        intent.putExtra("TOKYO",key);

        startActivity(intent);
    }

    public void WebMotors(View view){
        key = 3;

        Intent intent = new Intent(this, Todas.class);
        intent.putExtra("TOKYO", key);

        startActivity(intent);
    }

    public void MercadoFree(View view){
        key = 4;

        Intent intent = new Intent(this, Todas.class);
        intent.putExtra("TOKYO", key);

        startActivity(intent);
    }

    public void Magalu(View view){
        key = 5;

        Intent intent = new Intent(this,Todas.class);
        intent.putExtra("TOKYO",key);

        startActivity(intent);
    }

    public void About(View view){

        Intent intent = new Intent(this,About.class);

        startActivity(intent);
    }

}
