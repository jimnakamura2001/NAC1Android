package com.example.nacandroid;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class Todas extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_todas);

        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();

        if(bundle != null){
            int chave = bundle.getInt("TOKYO");

            if(chave == 1){
                WebView webview = findViewById(R.id.webview);
                webview.setWebViewClient(new WebViewClient());

                webview.getSettings().setJavaScriptEnabled(true);

                webview.loadUrl("https://www.submarino.com.br/");
            }

            if(chave == 2){
                WebView webview = findViewById(R.id.webview);
                webview.setWebViewClient(new WebViewClient());

                webview.getSettings().setJavaScriptEnabled(true);

                webview.loadUrl("https://www.ebay.com/");
            }

            if(chave ==3){
                WebView webView = findViewById(R.id.webview);
                webView.setWebViewClient(new WebViewClient());

                webView.getSettings().setJavaScriptEnabled(true);

                webView.loadUrl("https://www.webmotors.com.br/");
            }

            if(chave == 4){
                WebView webView = findViewById(R.id.webview);
                webView.setWebViewClient(new WebViewClient());

                webView.getSettings().setJavaScriptEnabled(true);

                webView.loadUrl("https://www.mercadolivre.com/");
            }

            if(chave ==5){
                WebView webView = findViewById(R.id.webview);
                webView.setWebViewClient(new WebViewClient());

                webView.getSettings().setJavaScriptEnabled(true);

                webView.loadUrl("https://www.magazineluiza.com.br/");
            }
        }
    }
}
